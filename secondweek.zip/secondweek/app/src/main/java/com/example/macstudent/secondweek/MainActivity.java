package com.example.macstudent.secondweek;

import android.content.Context;
import android.hardware.SensorManager;
import android.hardware.camera2.CameraManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.squareup.seismic.ShakeDetector;

public class MainActivity extends AppCompatActivity implements ShakeDetector.Listener {


    Boolean onLight = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //1.VARIABLES USING WHILE FONE IS SHAKING
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);

    }

    @Override
    public void hearShake() {
        //2.THIS FUNCTION GONNA CALL AUTOMAGICALLY WHEN WE SHAKE THE FONE
        Log.d("hk","shake");
        Toast.makeText(this,"shaking",Toast.LENGTH_SHORT).show();

        //turn light when fone shakes
        CameraManager cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        try {
            // 1. which camera do you want (Front or back camera?!)
            String cameraID = cameraManager.getCameraIdList()[0];   // BACK CAMERA?

            // 2. turn the flash on
            // turn on

            if (onLight == false) {
                cameraManager.setTorchMode(cameraID, true);
                Log.d("hk", "Turning flash ON!");
                Toast.makeText(this, "Turning flash ON!", Toast.LENGTH_SHORT).show();

                onLight = true;
            }
            else {
                cameraManager.setTorchMode(cameraID, false);

                Log.d("hk", "Turning flash OFF!");
                Toast.makeText(this, "Turning flash OFF!", Toast.LENGTH_SHORT).show();

                onLight = false;
            }

            // turn off
            //cameraManager.setTorchMode(cameraID, false);
        }
        catch(Exception e)
        {
            Log.d("hk","error");
            Toast.makeText(this,"error while turning on flash",Toast.LENGTH_SHORT).show();
        }

        //turn on flash
    }
}
