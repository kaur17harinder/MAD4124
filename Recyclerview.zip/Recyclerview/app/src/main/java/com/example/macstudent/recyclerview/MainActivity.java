package com.example.macstudent.recyclerview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;



  public class MainActivity extends AppCompatActivity implements MyAdapter.ItemClickListener{


    //create an adapter variable
    private MyAdapter mAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //define the data for each row
        ArrayList<String> movies = new ArrayList<>();

        movies.add("Prison break");
        movies.add("Sherlock homles");
        movies.add("Friends");
        movies.add("The 100");
        movies.add("Suits");



        //ui nonsense
        RecyclerView recyclerView = findViewById(R.id.my_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        LinearLayoutManager mlm = (LinearLayoutManager) recyclerView.getLayoutManager();

        //setting adapter variable
        mAdapter = new MyAdapter(this, movies);
        mAdapter.setClickListener(this); //to deal with clicks
        recyclerView.setAdapter(mAdapter);

    }

      @Override
      public void onItemClick(View view, int position) {

      }
  }
